import React, { Fragment } from 'react';
import EditStudent from '../../components/EditStudent/EditStudent';

const Edit = () => {
  return (
    <Fragment>
      <EditStudent />
    </Fragment>
  );
};

export default Edit;